"""
AI-EnviroGuard — Flask backend.
Serves the two-page command center and computes all analytics:
validated AQI, hotspot detection, forecasting, alerts, risk score,
recommendations and CSV export.

Run:  python app.py     (or: flask run)
Then open http://127.0.0.1:5000
"""
import io
import json
import numpy as np
import pandas as pd
from flask import Flask, render_template, jsonify, Response

from what_if_demo import (POLLUTANTS, subindices_for, overall_aqi,
                          dominant_pollutant, aqi_category, category_color,
                          health_risk_for)

app = Flask(__name__)
DATA_PATH = "data/aqi_clean_demo.csv"
FORECAST_HORIZON = 6          # hours ahead
TREND_WINDOW = 6              # hours for "recent baseline"


# ---------------------------------------------------------------- data load
def load_data():
    df = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])
    df = df.sort_values(["sensor_id", "timestamp"]).reset_index(drop=True)
    # ---- validated subindices recomputed from raw concentrations ----
    subs = df.apply(lambda r: subindices_for(r["PM2.5"], r["PM10"], r["NO2"],
                                             r["SO2"], r["CO"], r["O3"]),
                    axis=1, result_type="expand")
    for p in POLLUTANTS:
        df[f"sub_{p}"] = subs[p]
    df["validated_AQI"] = subs.apply(overall_aqi, axis=1)
    df["dominant"] = subs.apply(dominant_pollutant, axis=1)
    df["category"] = df["validated_AQI"].apply(aqi_category)

    # ---- validation report: compare source AQI cols vs recomputed ----
    src_cols = {"PM2.5": "AQI_PM2.5", "PM10": "AQI_PM10", "NO2": "AQI_NO2",
                "SO2": "AQI_SO2", "CO": "AQI_CO", "O3": "AQI_O3"}
    validation = {}
    for p, col in src_cols.items():
        recomputed = df[f"sub_{p}"]
        source = pd.to_numeric(df[col], errors="coerce")
        diff = (source - recomputed).abs()
        agree = float((diff <= 2).mean() * 100)
        validation[p] = {
            "agreement_pct": round(agree, 1),
            "source_max": float(source.max()),
            "recomputed_max": float(recomputed.max()),
            "trusted": bool(agree >= 90),
        }
    return df, validation


DF, VALIDATION = load_data()


def j(x):
    """JSON-safe conversion."""
    if isinstance(x, (np.integer,)):  return int(x)
    if isinstance(x, (np.floating,)): return None if np.isnan(x) else float(x)
    if isinstance(x, (np.bool_,)):    return bool(x)
    if isinstance(x, pd.Timestamp):   return x.strftime("%Y-%m-%d %H:%M:%S")
    return x


# ---------------------------------------------------------------- analytics
def forecast(vals, horizon=FORECAST_HORIZON):
    """Lightweight linear-regression forecast with +/-1 sigma band."""
    y = np.asarray([v for v in vals if v is not None], dtype=float)
    if len(y) < 4:
        return None
    n = min(24, len(y))
    yv = y[-n:]
    x = np.arange(n, dtype=float)
    coef = np.polyfit(x, yv, 1)
    resid = yv - np.polyval(coef, x)
    sd = float(resid.std()) if len(resid) > 1 else 0.0
    fx = np.arange(n, n + horizon, dtype=float)
    pred = np.polyval(coef, fx)
    pred = np.maximum(pred, 0)
    return {
        "values": [round(float(v), 2) for v in pred],
        "upper":  [round(float(v + sd), 2) for v in pred],
        "lower":  [round(float(max(v - sd, 0)), 2) for v in pred],
        "slope":  round(float(coef[0]), 3),
        "next":   round(float(pred[0]), 1),
        "mean":   round(float(pred.mean()), 1),
    }


def trend_pct(series):
    """% change of last reading vs recent baseline (mean of prior window)."""
    s = [v for v in series if v is not None]
    if len(s) < TREND_WINDOW + 1:
        return 0.0
    base = float(np.mean(s[-(TREND_WINDOW + 1):-1]))
    if base == 0:
        return 0.0
    return round((s[-1] - base) / base * 100, 1)


def trend_label(pct):
    if pct > 8:  return "Increasing"
    if pct < -8: return "Decreasing"
    return "Stable"


def risk_score(aqi, t_pct, fc_aqi, valid_ratio, anomaly):
    """Transparent composite 0-100."""
    severity  = min((aqi or 0) / 300 * 100, 100)
    trend_c   = min(max((t_pct + 20) / 40 * 100, 0), 100)
    forecast_c= min((fc_aqi or 0) / 300 * 100, 100)
    quality_c = (1 - valid_ratio) * 100
    anomaly_c = 100.0 if anomaly else 20.0
    score = (severity * 0.40 + trend_c * 0.20 + forecast_c * 0.20
             + quality_c * 0.12 + anomaly_c * 0.08)
    score = round(min(max(score, 0), 100))
    if score <= 20:   label = "LOW"
    elif score <= 40: label = "MODERATE"
    elif score <= 60: label = "ELEVATED"
    elif score <= 80: label = "HIGH"
    else:             label = "SEVERE"
    return {
        "score": score, "label": label,
        "factors": {
            "Pollutant severity": round(severity),
            "Pollution trend":    round(trend_c),
            "Forecast risk":      round(forecast_c),
            "Data quality":       round(quality_c),
            "Sensor anomaly":     round(anomaly_c),
        },
        "weights": {"Pollutant severity": 0.40, "Pollution trend": 0.20,
                    "Forecast risk": 0.20, "Data quality": 0.12,
                    "Sensor anomaly": 0.08},
    }


def build_alerts(g, latest, fc, t_pct):
    """Rule-based early warnings for one sensor group."""
    alerts = []
    sid = latest["sensor_id"]
    aqi = latest["validated_AQI"]
    recent = g["validated_AQI"].tail(4)

    if t_pct >= 25:
        alerts.append({"level": "HIGH POLLUTION WARNING", "color": "#F87171",
            "msg": f"{sid} shows a sustained pollution increase of {t_pct}% vs its recent baseline.",
            "rec": "Increase monitoring frequency and inspect nearby emission sources."})
    elif t_pct >= 10:
        alerts.append({"level": "RISING TREND", "color": "#FB923C",
            "msg": f"{sid} pollution is trending upward (+{t_pct}% vs baseline).",
            "rec": "Watch next reporting period; verify industrial activity in the area."})
    if len(recent) >= 3 and (recent.tail(3) > 150).all():
        alerts.append({"level": "SUSTAINED HIGH POLLUTION", "color": "#F87171",
            "msg": f"AQI has stayed above 150 for the last 3 consecutive hours at {sid}.",
            "rec": "Trigger an early-warning notification to nearby residential zones."})
    if bool(latest.get("anomaly_flag")) or latest["status"] == "Spike Alert":
        alerts.append({"level": "ABNORMAL SENSOR READING", "color": "#A855F7",
            "msg": f"{sid} reported a spike/anomalous reading at {j(latest['timestamp'])}.",
            "rec": "Investigate the sensor and cross-check with a neighbouring station."})
    if fc and fc["mean"] > 150:
        alerts.append({"level": "FORECASTED HIGH-RISK PERIOD", "color": "#d946a8",
            "msg": f"Forecast indicates AQI averaging ~{fc['mean']} over the next {FORECAST_HORIZON}h.",
            "rec": "Pre-emptively notify sensitive facilities and prepare mitigation measures."})
    if latest["data_quality"] != "Valid" or bool(latest.get("missing_flag")):
        alerts.append({"level": "INCOMPLETE SENSOR DATA", "color": "#FBBF24",
            "msg": f"{sid} latest record is flagged '{latest['data_quality']}'.",
            "rec": "Schedule maintenance / verify telemetry link before relying on readings."})
    if not alerts:
        alerts.append({"level": "ALL CLEAR", "color": "#4ADE80",
            "msg": f"No active warnings for {sid}. Conditions within expected bounds.",
            "rec": "Continue routine monitoring."})
    return alerts


def recommendations(cat, dominant, t_pct, anomaly):
    recs = []
    if aqi_rank(cat) >= 2:
        recs.append(f"Prioritize {dominant} reduction — it is the dominant contributor to current risk.")
    if t_pct > 10:
        recs.append("Inspect nearby emission sources — pollution is on a rising trend.")
    if aqi_rank(cat) >= 3:
        recs.append("Trigger an early-warning notification for surrounding residential zones.")
        recs.append("Increase monitoring frequency to 15-minute intervals at this station.")
    if anomaly:
        recs.append("Investigate abnormal sensor readings before automated decision-making.")
    if aqi_rank(cat) <= 1 and abs(t_pct) <= 10:
        recs.append("Conditions stable — maintain standard monitoring cadence.")
    recs.append("Monitor surrounding populated areas until readings return to baseline.")
    return recs[:5]


def aqi_rank(cat):
    order = ["Good", "Moderate", "Unhealthy for Sensitive Groups",
             "Unhealthy", "Very Unhealthy", "Hazardous"]
    return order.index(cat) if cat in order else 0


def explain(latest, baseline, t_pct, fc):
    dom = latest["dominant"]
    val = latest[dom]
    aqi = latest["validated_AQI"]
    cat = latest["category"]
    above = "above" if val >= baseline else "below"
    tl = trend_label(t_pct).lower()
    fc_txt = ""
    if fc:
        fc_txt = (f" The {FORECAST_HORIZON}-hour forecast projects an average "
                  f"AQI of ~{fc['mean']}, indicating conditions are expected to "
                  f"{'worsen' if fc['slope'] > 0.5 else 'ease' if fc['slope'] < -0.5 else 'hold steady'}.")
    return (f"{dom} is currently the dominant contributor to environmental risk at "
            f"{latest['sensor_id']} ({latest['location']}). Its concentration of "
            f"{round(val,1)} is {above} the recent sensor baseline of {round(baseline,1)}, "
            f"and the trend is {tl} ({t_pct:+}%). Validated AQI stands at {round(aqi)} "
            f"({cat}).{fc_txt} Continued elevation may increase health risk in nearby "
            f"populated areas.")


def sensor_bundle(sid):
    g = DF[DF["sensor_id"] == sid].sort_values("timestamp").reset_index(drop=True)
    latest = g.iloc[-1]
    records = [{
        "timestamp": j(r["timestamp"]), "PM2.5": j(r["PM2.5"]), "PM10": j(r["PM10"]),
        "NO2": j(r["NO2"]), "SO2": j(r["SO2"]), "CO": j(r["CO"]), "O3": j(r["O3"]),
        "validated_AQI": j(r["validated_AQI"]), "category": r["category"],
    } for _, r in g.iterrows()]

    subs_latest = {p: j(latest[f"sub_{p}"]) for p in POLLUTANTS}
    total = sum(v for v in subs_latest.values() if v) or 1
    contribution = {p: {"abs": j(subs_latest[p]),
                        "pct": round((subs_latest[p] or 0) / total * 100, 1)}
                    for p in POLLUTANTS}

    rolling = g["validated_AQI"].rolling(6, min_periods=1).mean().round(2).tolist()
    baseline = float(g[latest["dominant"]].tail(TREND_WINDOW + 1).iloc[:-1].mean()) \
        if len(g) > TREND_WINDOW else float(g[latest["dominant"]].mean())
    t_pct = trend_pct(g["validated_AQI"].tolist())
    fc = forecast(g["validated_AQI"].tolist())
    fc_times = [(g["timestamp"].iloc[-1] + pd.Timedelta(hours=i + 1)).strftime("%Y-%m-%d %H:%M:%S")
                for i in range(FORECAST_HORIZON)]

    valid_ratio = float((g["data_quality"] == "Valid").mean())
    anomaly = bool(g["anomaly_flag"].tail(6).any()) or (g["status"].tail(3) == "Spike Alert").any()
    risk = risk_score(latest["validated_AQI"], t_pct,
                      fc["mean"] if fc else latest["validated_AQI"],
                      valid_ratio, anomaly)

    return {
        "sensor_id": sid, "location": latest["location"],
        "records": records, "rolling": rolling,
        "latest": {
            "timestamp": j(latest["timestamp"]),
            "PM2.5": j(latest["PM2.5"]), "PM10": j(latest["PM10"]),
            "NO2": j(latest["NO2"]), "SO2": j(latest["SO2"]),
            "CO": j(latest["CO"]), "O3": j(latest["O3"]),
            "battery": j(latest["battery"]), "status": latest["status"],
            "temperature": j(latest["temperature"]), "humidity": j(latest["humidity"]),
            "validated_AQI": j(latest["validated_AQI"]),
            "category": latest["category"], "dominant": latest["dominant"],
            "subs": subs_latest, "data_quality": latest["data_quality"],
            "anomaly_flag": bool(latest["anomaly_flag"]),
        },
        "baseline": round(baseline, 2),
        "trend_pct": t_pct, "trend": trend_label(t_pct),
        "forecast": fc, "forecast_times": fc_times,
        "contribution": contribution,
        "explanation": explain(latest, baseline, t_pct, fc),
        "alerts": build_alerts(g, latest, fc, t_pct),
        "risk": risk,
        "health_risk": health_risk_for(latest["validated_AQI"]),
        "recommendations": recommendations(latest["category"], latest["dominant"],
                                           t_pct, anomaly),
        "data_quality": {
            "total_records": int(len(g)),
            "valid_records": int((g["data_quality"] == "Valid").sum()),
            "incomplete_records": int((g["data_quality"] != "Valid").sum()),
            "missing_records": int(g["missing_flag"].sum()),
            "anomaly_records": int(g["anomaly_flag"].sum()),
            "reliability_pct": round(valid_ratio * 100, 1),
            "last_timestamp": j(latest["timestamp"]),
        },
    }


def overview():
    latest = DF.sort_values("timestamp").groupby("sensor_id").tail(1)
    active = latest[latest["status"] == "Active"]
    high_risk = latest[latest["validated_AQI"] > 150]
    hotspot_row = latest.loc[latest["validated_AQI"].idxmax()]

    net_subs = {p: float(DF[f"sub_{p}"].mean()) for p in POLLUTANTS}
    net_dominant = max(net_subs, key=net_subs.get)

    kpis = {
        "active_sensors": int((latest["status"] == "Active").sum()),
        "total_sensors": int(latest.shape[0]),
        "high_risk_sensors": int(high_risk.shape[0]),
        "avg_pm25": round(float(latest["PM2.5"].mean()), 1),
        "avg_pm10": round(float(latest["PM10"].mean()), 1),
        "avg_aqi": round(float(latest["validated_AQI"].mean()), 1),
        "hotspot_location": hotspot_row["location"],
        "dominant_pollutant": net_dominant,
        "data_quality_pct": round(float((DF["data_quality"] == "Valid").mean() * 100), 1),
    }

    roster = []
    for _, r in latest.iterrows():
        roster.append({
            "sensor_id": r["sensor_id"], "location": r["location"],
            "aqi": j(r["validated_AQI"]), "category": r["category"],
            "color": category_color(r["validated_AQI"]),
            "PM2.5": j(r["PM2.5"]), "PM10": j(r["PM10"]), "NO2": j(r["NO2"]),
            "SO2": j(r["SO2"]), "CO": j(r["CO"]), "O3": j(r["O3"]),
            "battery": j(r["battery"]), "status": r["status"],
            "data_quality": r["data_quality"], "timestamp": j(r["timestamp"]),
            "temperature": j(r["temperature"]), "humidity": j(r["humidity"]),
            "dominant": r["dominant"],
        })

    hs_g = DF[DF["sensor_id"] == hotspot_row["sensor_id"]]
    hs_trend = trend_pct(hs_g["validated_AQI"].tolist())
    hotspot = {
        "sensor_id": hotspot_row["sensor_id"], "location": hotspot_row["location"],
        "aqi": j(hotspot_row["validated_AQI"]), "category": hotspot_row["category"],
        "color": category_color(hotspot_row["validated_AQI"]),
        "dominant": hotspot_row["dominant"],
        "dominant_value": j(hotspot_row[hotspot_row["dominant"]]),
        "trend": trend_label(hs_trend), "trend_pct": hs_trend,
        "action": recommendations(hotspot_row["category"], hotspot_row["dominant"],
                                  hs_trend, bool(hotspot_row["anomaly_flag"]))[0],
    }

    health = []
    for _, r in latest.iterrows():
        g = DF[DF["sensor_id"] == r["sensor_id"]]
        health.append({
            "sensor_id": r["sensor_id"], "location": r["location"],
            "battery": j(r["battery"]),
            "battery_missing": bool(pd.isna(r["battery"])),
            "status": "Online" if r["status"] in ("Active", "Spike Alert") else "Offline",
            "raw_status": r["status"],
            "missing_records": int(g["missing_flag"].sum()),
            "reliability_pct": round(float((g["data_quality"] == "Valid").mean() * 100), 1),
            "last_update": j(r["timestamp"]),
        })

    cat_counts = DF["category"].value_counts().to_dict()
    network = {
        "avg_conc": {p: round(float(latest[p].mean()), 2) for p in POLLUTANTS},
        "max_conc": {p: round(float(DF[p].max()), 2) for p in POLLUTANTS},
        "avg_aqi_by_sensor": [{"sensor": r["sensor_id"], "aqi": j(r["validated_AQI"]),
                               "color": category_color(r["validated_AQI"])}
                              for _, r in latest.iterrows()],
        "aqi_distribution": cat_counts,
    }
    return {"kpis": kpis, "roster": roster, "hotspot": hotspot,
            "health": health, "network": network}


# ---------------------------------------------------------------- routes
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/bootstrap")
def bootstrap():
    payload = {
        "overview": overview(),
        "sensors": {sid: sensor_bundle(sid) for sid in sorted(DF["sensor_id"].unique())},
        "validation": VALIDATION,
        "generated_at": j(DF["timestamp"].max()),
    }
    return Response(json.dumps(payload, default=j), mimetype="application/json")


@app.route("/api/export/clean")
def export_clean():
    buf = io.StringIO()
    DF.to_csv(buf, index=False)
    return Response(buf.getvalue(), mimetype="text/csv", headers={
        "Content-Disposition": "attachment; filename=aqi_clean_demo.csv"})


@app.route("/api/export/analyzed")
def export_analyzed():
    out = DF[["timestamp", "sensor_id", "location", "validated_AQI",
              "category", "dominant"]].copy()
    out.columns = ["timestamp", "sensor_id", "location", "aqi", "risk_level",
                   "dominant_pollutant"]
    fc_map, rs_map, alert_map = {}, {}, {}
    for sid in sorted(DF["sensor_id"].unique()):
        b = sensor_bundle(sid)
        fc_map[sid] = b["forecast"]["next"] if b["forecast"] else None
        rs_map[sid] = b["risk"]["score"]
        alert_map[sid] = "; ".join(a["level"] for a in b["alerts"]
                                   if a["level"] != "ALL CLEAR") or "None"
    out["forecast_next_aqi"] = out["sensor_id"].map(fc_map)
    # what-if at +25% PM2.5 per record
    wi = DF.apply(lambda r: overall_aqi(
        subindices_for(r["PM2.5"] * 1.25, r["PM10"], r["NO2"],
                       r["SO2"], r["CO"], r["O3"])), axis=1)
    out["whatif_aqi_pm25_plus25"] = wi.round(1)
    out["risk_score"] = out["sensor_id"].map(rs_map)
    out["alert_status"] = out["sensor_id"].map(alert_map)
    buf = io.StringIO()
    out.to_csv(buf, index=False)
    return Response(buf.getvalue(), mimetype="text/csv", headers={
        "Content-Disposition": "attachment; filename=aqi_analyzed_export.csv"})


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=5000)
