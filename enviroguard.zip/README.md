# AI-EnviroGuard — AI-Enabled Industrial Environmental Monitoring, Risk Assessment & Early-Warning System

A two-page **Environmental Command Center** that turns raw IoT air-quality sensor data into
validated AQI, hotspot detection, forecasts, early warnings, a transparent environmental
risk score, health-risk guidance and an interactive PM2.5 what-if simulator.

---

## Quick start

```bash
pip install -r requirements.txt
python app.py
# open http://127.0.0.1:5000
```

No build step. The backend pre-computes every analytic and ships one JSON payload
(`/api/bootstrap`); the frontend renders instantly.

## Project layout

```
enviroguard/
├── app.py                  # Flask backend — all analytics + API + CSV export
├── what_if_demo.py         # EPA breakpoint AQI engine (reused, never duplicated)
├── data/
│   └── aqi_clean_demo.csv  # cleaned sensor dataset (300 rows, 4 stations, 96 h)
├── templates/index.html    # two-page command-center UI
├── static/style.css        # industrial dark theme
├── static/app.js           # rendering + client-side what-if recalculation
├── requirements.txt
└── screenshots/            # demo captures
```

## Pages

**01 · Command Center** — 8 network KPIs · colour-coded sensor roster (green→purple by
validated AQI; click a row for the full metric set) · pollution hotspot panel with
recommended action · sensor health (battery, online status, missing records, reliability,
last update) · network-wide avg/max concentrations + AQI distribution donut.

**02 · AI Analytics & Decision Support** — sidebar (sensor / time range / pollutant /
PM2.5 what-if slider ±50 %) · time-series with rolling average, baseline, 6 h forecast
and ±1σ band · pollutant contribution bars (absolute + %) · auto-generated explanation ·
rule-based early warnings · transparent 0–100 composite risk score with factor
breakdown · health-risk guidance · current-vs-what-if comparison (AQI, category, risk
score, % change) · recommendation engine · data-quality audit · CSV export
(cleaned + analyzed).

## Data validation (important)

AQI is **never trusted blindly**. Every subindex is recomputed from raw concentrations
using EPA breakpoint tables (`what_if_demo.py`) and compared against the source columns:

| Column    | Result                                             |
|-----------|----------------------------------------------------|
| AQI_PM2.5 | agrees with recomputation → trusted                |
| AQI_PM10  | agrees (minor gaps) → recomputed used              |
| AQI_NO2/SO2/CO | agrees → trusted                             |
| **AQI_O3**| **fails — source values 1 198–29 372 are physically impossible** → flagged, recomputed from O₃ concentration |

Invalid/incomplete records are excluded from KPI, risk and forecast math and surfaced
in the Data Quality panel.

Assumed units (verified against the sane source columns): PM2.5/PM10 µg/m³,
NO₂/SO₂/O₃ ppb, CO ppm.

## Methods

- **Validated AQI** — max of six EPA piecewise-linear subindices.
- **Forecast** — linear regression on the trailing 24 h, projected 6 h ahead with a
  ±1σ residual band; values always labelled *predicted*.
- **Risk score (0–100)** — 40 % pollutant severity · 20 % trend · 20 % forecast ·
  12 % data quality · 8 % sensor anomaly. All factors shown in the UI.
- **Alerts** — rapid increase (≥25 % vs 6 h baseline), sustained AQI > 150 (3 h),
  anomaly/spike flags, forecasted high-risk periods, incomplete data.
- **What-if** — slider rescales PM2.5 ±50 %, recalculates the PM2.5 subindex, overall
  AQI, contribution mix, risk category, risk score and % change live in the browser.

## Hackathon demo flow

1. Open **Command Center** → network KPIs + colour-coded stations.
2. Point at the **hotspot panel** → highest-risk industrial zone + recommended action.
3. Switch to **AI Analytics**, select that sensor.
4. Show historical trend → forecast → dominant pollutant → AI explanation.
5. Drag the PM2.5 slider to **+25 %** → watch AQI / risk category / risk score rise.
6. Drag to **−30 %** → watch them fall; read the recommendation list.
7. Finish on Data Quality + CSV export; explain how the same pipeline ingests live
   IoT streams (MQTT/REST) and fires the early-warning rules in real time.

## API

| Endpoint                | Purpose                                        |
|-------------------------|------------------------------------------------|
| `GET /`                 | dashboard                                      |
| `GET /api/bootstrap`    | one JSON payload: overview + per-sensor analytics |
| `GET /api/export/clean` | cleaned CSV download                           |
| `GET /api/export/analyzed` | enriched CSV (AQI, risk, dominant, forecast, what-if, alerts) |
