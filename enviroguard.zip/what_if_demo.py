"""
what_if_demo.py — Validated AQI recalculation engine (EPA breakpoint method).

The source CSV's AQI columns are NOT trusted blindly:
  - AQI_O3 contains physically unrealistic values (1198 - 29372).
  - All subindices are recomputed from raw concentrations and compared
    against the source columns; mismatches are flagged as data-quality issues.

Assumed units (validated against the sane source columns):
  PM2.5, PM10 : ug/m3
  NO2, SO2, O3: ppb
  CO          : ppm
"""

# (C_low, C_high, AQI_low, AQI_high)
BP = {
    "PM2.5": [(0.0, 12.0, 0, 50), (12.1, 35.4, 51, 100), (35.5, 55.4, 101, 150),
              (55.5, 150.4, 151, 200), (150.5, 250.4, 201, 300),
              (250.5, 350.4, 301, 400), (350.5, 500.4, 401, 500)],
    "PM10":  [(0, 54, 0, 50), (55, 154, 51, 100), (155, 254, 101, 150),
              (255, 354, 151, 200), (355, 424, 201, 300),
              (425, 504, 301, 400), (505, 604, 401, 500)],
    "NO2":   [(0, 53, 0, 50), (54, 100, 51, 100), (101, 360, 101, 150),
              (361, 649, 151, 200), (650, 1249, 201, 300),
              (1250, 1649, 301, 400), (1650, 2049, 401, 500)],
    "SO2":   [(0, 35, 0, 50), (36, 75, 51, 100), (76, 185, 101, 150),
              (186, 304, 151, 200), (305, 604, 201, 300),
              (605, 804, 301, 400), (805, 1004, 401, 500)],
    "CO":    [(0.0, 4.4, 0, 50), (4.5, 9.4, 51, 100), (9.5, 12.4, 101, 150),
              (12.5, 15.4, 151, 200), (15.5, 30.4, 201, 300),
              (30.5, 40.4, 301, 400), (40.5, 50.4, 401, 500)],
    "O3":    [(0, 54, 0, 50), (55, 70, 51, 100), (71, 85, 101, 150),
              (86, 105, 151, 200), (106, 200, 201, 300),
              (201, 300, 301, 400), (301, 400, 401, 500)],
}

POLLUTANTS = ["PM2.5", "PM10", "NO2", "SO2", "CO", "O3"]


def aqi_from_breakpoints(conc, pollutant):
    """Piecewise-linear EPA AQI for one pollutant concentration."""
    if conc is None or conc != conc:  # None / NaN
        return None
    c = float(conc)
    for c_lo, c_hi, a_lo, a_hi in BP[pollutant]:
        if c_lo <= c <= c_hi:
            return round((a_hi - a_lo) / (c_hi - c_lo) * (c - c_lo) + a_lo, 1)
    # beyond table -> clamp to 500
    return 500.0


def subindices_for(pm25, pm10, no2, so2, co, o3):
    """Return validated subindices dict for all six pollutants."""
    vals = {"PM2.5": pm25, "PM10": pm10, "NO2": no2,
            "SO2": so2, "CO": co, "O3": o3}
    return {p: aqi_from_breakpoints(vals[p], p) for p in POLLUTANTS}


def overall_aqi(subs):
    """Overall validated AQI = max of valid subindices. Accepts dict or Series."""
    vals = dict(subs)
    valid = [v for v in vals.values() if v is not None and v == v]
    return max(valid) if valid else None


def dominant_pollutant(subs):
    vals = dict(subs)
    valid = {k: v for k, v in vals.items() if v is not None and v == v}
    return max(valid, key=valid.get) if valid else None


def aqi_category(aqi):
    if aqi is None:
        return "Unknown"
    if aqi <= 50:  return "Good"
    if aqi <= 100: return "Moderate"
    if aqi <= 150: return "Unhealthy for Sensitive Groups"
    if aqi <= 200: return "Unhealthy"
    if aqi <= 300: return "Very Unhealthy"
    return "Hazardous"


CATEGORY_COLORS = {
    "Good": "#4ADE80",
    "Moderate": "#FBBF24",
    "Unhealthy for Sensitive Groups": "#FB923C",
    "Unhealthy": "#F87171",
    "Very Unhealthy": "#A855F7",
    "Hazardous": "#d946a8",
    "Unknown": "#4b5866",
}


def category_color(aqi):
    return CATEGORY_COLORS[aqi_category(aqi)]


def health_risk_for(aqi):
    """General environmental-health guidance (not medical diagnosis)."""
    cat = aqi_category(aqi)
    table = {
        "Good": ("LOW CONCERN", "Air quality is satisfactory. Enjoy normal outdoor activity."),
        "Moderate": ("SENSITIVE GROUPS CAUTION", "Acceptable for most. Unusually sensitive individuals should consider reducing prolonged outdoor exertion."),
        "Unhealthy for Sensitive Groups": ("SENSITIVE GROUPS WARNING", "Children, elderly and people with respiratory conditions should reduce outdoor exertion near this zone."),
        "Unhealthy": ("INCREASED HEALTH CONCERN", "Everyone may begin to experience effects. Limit prolonged outdoor activity; sensitive groups should stay indoors."),
        "Very Unhealthy": ("HEALTH ALERT", "Serious health effects possible for the general population. Avoid outdoor activity in the affected area."),
        "Hazardous": ("EMERGENCY-LEVEL WARNING", "Emergency conditions. Entire population at risk. Remain indoors, seal ventilation, follow authority instructions."),
        "Unknown": ("NO DATA", "Insufficient valid data to assess health risk."),
    }
    label, guidance = table[cat]
    return {"category": cat, "label": label, "guidance": guidance,
            "color": CATEGORY_COLORS[cat]}
