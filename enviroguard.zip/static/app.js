/* AI-EnviroGuard — frontend logic (fetches /api/bootstrap, renders everything) */

const CAT_COLORS = {
  "Good": "#4ADE80", "Moderate": "#FBBF24",
  "Unhealthy for Sensitive Groups": "#FB923C", "Unhealthy": "#F87171",
  "Very Unhealthy": "#A855F7", "Hazardous": "#d946a8", "Unknown": "#4b5866"
};
const POLLUTANTS = ["PM2.5", "PM10", "NO2", "SO2", "CO", "O3"];

/* --- EPA breakpoint AQI (mirrors what_if_demo.py, used for what-if) --- */
const BP = {
  "PM2.5": [[0,12,0,50],[12.1,35.4,51,100],[35.5,55.4,101,150],[55.5,150.4,151,200],[150.5,250.4,201,300],[250.5,350.4,301,400],[350.5,500.4,401,500]],
  "PM10":  [[0,54,0,50],[55,154,51,100],[155,254,101,150],[255,354,151,200],[355,424,201,300],[425,504,301,400],[505,604,401,500]],
  "NO2":   [[0,53,0,50],[54,100,51,100],[101,360,101,150],[361,649,151,200],[650,1249,201,300],[1250,1649,301,400],[1650,2049,401,500]],
  "SO2":   [[0,35,0,50],[36,75,51,100],[76,185,101,150],[186,304,151,200],[305,604,201,300],[605,804,301,400],[805,1004,401,500]],
  "CO":    [[0,4.4,0,50],[4.5,9.4,51,100],[9.5,12.4,101,150],[12.5,15.4,151,200],[15.5,30.4,201,300],[30.5,40.4,301,400],[40.5,50.4,401,500]],
  "O3":    [[0,54,0,50],[55,70,51,100],[71,85,101,150],[86,105,151,200],[106,200,201,300],[201,300,301,400],[301,400,401,500]]
};
function aqiFromBP(c, p) {
  if (c === null || c === undefined || isNaN(c)) return null;
  for (const [lo, hi, alo, ahi] of BP[p]) {
    if (c >= lo && c <= hi) return Math.round(((ahi - alo) / (hi - lo) * (c - lo) + alo) * 10) / 10;
  }
  return 500;
}
function aqiCategory(a) {
  if (a === null) return "Unknown";
  if (a <= 50) return "Good"; if (a <= 100) return "Moderate";
  if (a <= 150) return "Unhealthy for Sensitive Groups";
  if (a <= 200) return "Unhealthy"; if (a <= 300) return "Very Unhealthy";
  return "Hazardous";
}
function riskLabel(s) {
  if (s <= 20) return "LOW"; if (s <= 40) return "MODERATE";
  if (s <= 60) return "ELEVATED"; if (s <= 80) return "HIGH"; return "SEVERE";
}

let DATA = null;
const state = { sensor: null, range: 96, pollutant: "PM2.5", whatif: 0 };

const $ = id => document.getElementById(id);
const PLOTLY_CFG = { displayModeBar: false, responsive: true };
const BASE_LAYOUT = {
  paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "rgba(0,0,0,0)",
  font: { family: "IBM Plex Mono, monospace", color: "#7c8b9c", size: 10 },
  margin: { l: 42, r: 12, t: 10, b: 32 },
  xaxis: { gridcolor: "#182029", zerolinecolor: "#182029" },
  yaxis: { gridcolor: "#182029", zerolinecolor: "#182029" },
  showlegend: true,
  legend: { orientation: "h", y: 1.14, font: { size: 9 } }
};

/* ------------------------------------------------------------ boot */
fetch("/api/bootstrap").then(r => r.json()).then(d => {
  DATA = d;
  state.sensor = Object.keys(d.sensors).sort()[0];
  initClock(); initTabs(); renderPage1(); initSidebar(); renderAnalytics();
});

function initClock() {
  const tick = () => { $("live-clock").textContent = new Date().toLocaleTimeString("en-GB"); };
  tick(); setInterval(tick, 1000);
}
function initTabs() {
  document.querySelectorAll(".tab-btn").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    $(b.dataset.page).classList.add("active");
    if (b.dataset.page === "page2") setTimeout(() => Plotly.Plots.resize("chart-timeseries"), 60);
  }));
}

/* ------------------------------------------------------------ PAGE 1 */
function renderPage1() {
  const { kpis, roster, hotspot, health, network } = DATA.overview;

  /* KPI strip */
  const cells = [
    ["Active Sensors", `${kpis.active_sensors}/${kpis.total_sensors}`, "network stations", true],
    ["High-Risk Sensors", kpis.high_risk_sensors, "validated AQI > 150", kpis.high_risk_sensors === 0],
    ["Avg PM2.5", kpis.avg_pm25, "µg/m³ across network", false],
    ["Avg PM10", kpis.avg_pm10, "µg/m³ across network", false],
    ["Avg AQI", kpis.avg_aqi, aqiCategory(kpis.avg_aqi), false],
    ["Highest-Risk Zone", hotspot.location.split(" ")[0], hotspot.location, false],
    ["Dominant Pollutant", kpis.dominant_pollutant, "network-wide mean", false],
    ["Data Quality", kpis.data_quality_pct + "%", "valid records", true],
  ];
  $("kpi-strip").innerHTML = cells.map(([l, v, s, accent]) => `
    <div class="kpi-cell"><div class="kpi-label">${l}</div>
    <div class="kpi-value ${accent ? "accent" : ""}">${v}</div>
    <div class="kpi-sub">${s}</div></div>`).join("");

  /* roster */
  let html = `<div class="roster-head"><span>Sensor</span><span>Location</span>
    <span style="text-align:center">AQI</span><span>Category</span>
    <span class="metric">PM2.5</span><span class="metric">PM10</span>
    <span class="metric">NO₂</span><span class="metric">Batt</span><span style="text-align:right">Status</span></div>`;
  roster.forEach((s, i) => {
    html += `
    <div class="sensor-row" style="border-left-color:${s.color}" onclick="toggleDetail(${i})">
      <span class="sid">${s.sensor_id}</span><span class="loc">${s.location}</span>
      <span class="aqi-badge" style="background:${s.color}">${Math.round(s.aqi)}</span>
      <span class="cat" style="color:${s.color}">${s.category}</span>
      <span class="metric"><b>${s["PM2.5"]}</b></span><span class="metric"><b>${s.PM10}</b></span>
      <span class="metric"><b>${s.NO2}</b></span>
      <span class="metric"><b>${s.battery ?? "—"}</b></span>
      <span class="status-dot">${s.status === "Active" ? "🟢" : "🟠"}</span>
    </div>
    <div class="sensor-detail" id="detail-${i}">
      <span>SO₂<b>${s.SO2} ppb</b></span><span>CO<b>${s.CO} ppm</b></span>
      <span>O₃<b>${s.O3} ppb</b></span><span>Dominant<b>${s.dominant}</b></span>
      <span>Data Quality<b>${s.data_quality}</b></span><span>Last Update<b>${s.timestamp.slice(11,16)}</b></span>
    </div>`;
  });
  $("sensor-roster").innerHTML = html;

  /* hotspot */
  $("hotspot-block").innerHTML = `
    <div class="hotspot-headline" style="border-color:${hotspot.color}55">
      <div class="hotspot-aqi-big" style="color:${hotspot.color}">${Math.round(hotspot.aqi)}</div>
      <div class="hotspot-meta">
        <h3>HIGHEST RISK ZONE — ${hotspot.location}</h3>
        <p>${hotspot.sensor_id} · validated AQI · ${hotspot.category}</p>
      </div>
    </div>
    <div class="hotspot-fact-row">
      <div><span>Dominant pollutant</span>${hotspot.dominant} (${hotspot.dominant_value})</div>
      <div><span>Trend</span>${hotspot.trend} (${hotspot.trend_pct > 0 ? "+" : ""}${hotspot.trend_pct}%)</div>
      <div><span>Category</span><b style="color:${hotspot.color}">${hotspot.category}</b></div>
    </div>
    <div class="hotspot-rec">▸ RECOMMENDED ACTION: ${hotspot.action}</div>`;

  /* health */
  $("sensor-health").innerHTML = health.map(h => {
    const bat = h.battery ?? 0;
    const bcol = h.battery_missing ? "#4b5866" : bat > 60 ? "var(--good)" : bat > 30 ? "var(--moderate)" : "var(--unhealthy)";
    return `<div class="health-row" title="Last update: ${h.last_update}">
      <span class="sid">${h.sensor_id}</span>
      <span class="loc">${h.location}<br>updated ${h.last_update.slice(5,16)}</span>
      <span><div class="battery-bar-wrap"><div class="battery-bar" style="width:${bat}%;background:${bcol}"></div></div></span>
      <span style="font-size:10px;color:var(--text-dim)">${h.missing_records} missing rec.</span>
      <span class="reliability">${h.reliability_pct}%</span>
      <span class="status-tag" style="background:${h.status === "Online" ? "#14532d" : "#450a0a"};color:${h.status === "Online" ? "var(--good)" : "var(--unhealthy)"}">${h.status}</span>
    </div>`;
  }).join("");

  /* network charts */
  const pols = POLLUTANTS;
  Plotly.newPlot("chart-avgmax", [
    { x: pols, y: pols.map(p => network.avg_conc[p]), type: "bar", name: "Network avg",
      marker: { color: "#29d8e0" } },
    { x: pols, y: pols.map(p => network.max_conc[p]), type: "bar", name: "Network max",
      marker: { color: "#fbbf24" } }
  ], { ...BASE_LAYOUT, barmode: "group", yaxis: { ...BASE_LAYOUT.yaxis, title: "concentration" } }, PLOTLY_CFG);

  const cats = Object.keys(network.aqi_distribution);
  Plotly.newPlot("chart-distribution", [{
    labels: cats, values: cats.map(c => network.aqi_distribution[c]), type: "pie",
    hole: 0.55, marker: { colors: cats.map(c => CAT_COLORS[c] || "#4b5866") },
    textinfo: "label+percent", textfont: { size: 9 }
  }], { ...BASE_LAYOUT, showlegend: false,
        annotations: [{ text: "AQI<br>records", showarrow: false, font: { size: 10, color: "#7c8b9c" } }] }, PLOTLY_CFG);
}

function toggleDetail(i) { $("detail-" + i).classList.toggle("open"); }

/* ------------------------------------------------------------ PAGE 2 */
function initSidebar() {
  const sel = $("sel-sensor");
  sel.innerHTML = Object.values(DATA.sensors).map(s =>
    `<option value="${s.sensor_id}">${s.sensor_id} — ${s.location}</option>`).join("");
  sel.addEventListener("change", e => { state.sensor = e.target.value; renderAnalytics(); });
  $("sel-range").addEventListener("change", e => { state.range = +e.target.value; renderTimeseries(); });
  $("sel-pollutant").addEventListener("change", e => { state.pollutant = e.target.value; renderTimeseries(); });
  $("whatif-slider").addEventListener("input", e => {
    state.whatif = +e.target.value;
    $("whatif-val").textContent = (state.whatif > 0 ? "+" : "") + state.whatif + "%";
    renderWhatIf(); renderContribution();
  });
  $("btn-export-clean").addEventListener("click", () => location.href = "/api/export/clean");
  $("btn-export-analyzed").addEventListener("click", () => location.href = "/api/export/analyzed");
}

function S() { return DATA.sensors[state.sensor]; }

function renderAnalytics() {
  renderTimeseries(); renderContribution();
  $("ai-explain-text").textContent = S().explanation;
  renderForecastSummary(); renderRisk(); renderHealthRisk();
  renderAlerts(); renderWhatIf(); renderRecommendations(); renderDataQuality();
}

function renderTimeseries() {
  const s = S(), p = state.pollutant;
  const recs = s.records.slice(-state.range);
  const x = recs.map(r => r.timestamp);
  const y = recs.map(r => r[p]);
  const rolling = s.rolling.slice(-state.range);
  const isAQI = p === "validated_AQI";
  const base = isAQI ? null : s.baseline;

  const traces = [
    { x, y, name: p + " (raw)", type: "scatter", mode: "lines",
      line: { color: "#29d8e0", width: 1.6 } }
  ];
  if (isAQI) traces.push({ x, y: rolling, name: "6h rolling avg", type: "scatter",
    mode: "lines", line: { color: "#fbbf24", width: 2 } });
  if (base !== null) traces.push({ x: [x[0], x[x.length - 1]], y: [base, base],
    name: "historical baseline", type: "scatter", mode: "lines",
    line: { color: "#4b5866", dash: "dot" } });

  if (isAQI && s.forecast) {
    const fx = s.forecast_times;
    traces.push({ x: fx, y: s.forecast.upper, type: "scatter", mode: "lines",
      line: { width: 0 }, showlegend: false, hoverinfo: "skip" });
    traces.push({ x: fx, y: s.forecast.lower, type: "scatter", mode: "lines",
      fill: "tonexty", fillcolor: "rgba(168,85,247,0.12)", line: { width: 0 },
      name: "forecast range", hoverinfo: "skip" });
    traces.push({ x: [x[x.length - 1], ...fx], y: [y[y.length - 1], ...s.forecast.values],
      name: "forecast (predicted)", type: "scatter", mode: "lines+markers",
      line: { color: "#A855F7", dash: "dash", width: 2 }, marker: { size: 5 } });
  }
  $("ts-sensor-label").textContent = `${s.sensor_id} · ${s.location} · last ${state.range}h`;
  Plotly.react("chart-timeseries", traces,
    { ...BASE_LAYOUT, yaxis: { ...BASE_LAYOUT.yaxis, title: isAQI ? "Validated AQI" : p } }, PLOTLY_CFG);
}

function scenarioSubs() {
  const l = S().latest;
  const subs = { ...l.subs };
  const scenPM25 = l["PM2.5"] * (1 + state.whatif / 100);
  subs["PM2.5"] = aqiFromBP(scenPM25, "PM2.5");
  const aqi = Math.max(...Object.values(subs).filter(v => v !== null));
  return { subs, aqi, scenPM25: Math.round(scenPM25 * 10) / 10 };
}

function renderContribution() {
  const { subs } = scenarioSubs();
  const total = Object.values(subs).reduce((a, b) => a + (b || 0), 0) || 1;
  const pols = [...POLLUTANTS].reverse();
  const vals = pols.map(p => subs[p] || 0);
  const dom = S().latest.dominant;
  Plotly.react("chart-contribution", [{
    y: pols, x: vals, type: "bar", orientation: "h",
    text: pols.map(p => `${Math.round(subs[p] || 0)}  (${Math.round((subs[p] || 0) / total * 100)}%)`),
    textposition: "outside", textfont: { size: 9, color: "#7c8b9c" },
    marker: { color: pols.map(p => p === dom ? "#29d8e0" : "#2c3947") }
  }], { ...BASE_LAYOUT, showlegend: false,
        xaxis: { ...BASE_LAYOUT.xaxis, title: state.whatif !== 0 ?
          `subindex contribution to AQI (what-if ${state.whatif > 0 ? "+" : ""}${state.whatif}% PM2.5)` :
          "subindex contribution to validated AQI" } }, PLOTLY_CFG);
}

function renderForecastSummary() {
  const f = S().forecast, t = S().trend, tp = S().trend_pct;
  const arrow = t === "Increasing" ? "▲" : t === "Decreasing" ? "▼" : "◆";
  const col = t === "Increasing" ? "var(--unhealthy)" : t === "Decreasing" ? "var(--good)" : "var(--moderate)";
  $("forecast-summary").innerHTML = `
    <div class="forecast-item"><div class="fval" style="color:#A855F7">${f ? f.next : "—"}</div><div class="flabel">Next-hour AQI (predicted)</div></div>
    <div class="forecast-item"><div class="fval" style="color:#A855F7">${f ? f.mean : "—"}</div><div class="flabel">6h forecast mean</div></div>
    <div class="forecast-item"><div class="fval" style="color:${col}">${arrow} ${t}</div><div class="flabel">trend (${tp > 0 ? "+" : ""}${tp}%)</div></div>`;
}

function renderRisk(overrideScore) {
  const r = S().risk;
  const score = overrideScore !== undefined ? overrideScore : r.score;
  const label = riskLabel(score);
  const col = score <= 20 ? "var(--good)" : score <= 40 ? "var(--moderate)" :
              score <= 60 ? "var(--usg)" : score <= 80 ? "var(--unhealthy)" : "var(--hazardous)";
  const rows = Object.entries(r.factors).map(([k, v]) => `
    <div class="risk-factor-row"><span class="rf-label">${k}</span>
      <div class="risk-factor-bar-wrap"><div class="risk-factor-bar" style="width:${v}%"></div></div>
      <span class="rf-val">${v}</span></div>`).join("");
  $("risk-score-block").innerHTML = `
    <div class="risk-gauge-num" style="color:${col}">${score}<span style="font-size:16px;color:var(--text-faint)">/100</span></div>
    <div class="risk-gauge-label" style="color:${col}">${label}${overrideScore !== undefined ? " · WHAT-IF" : ""}</div>
    <div class="risk-factors">${rows}</div>`;
  return { score, label, col };
}

function renderHealthRisk() {
  const h = S().health_risk;
  $("health-risk-block").innerHTML = `
    <span class="health-cat-badge" style="background:${h.color}22;color:${h.color};border:1px solid ${h.color}55">${h.label}</span>
    <p class="health-guidance">${h.guidance}</p>
    <p class="health-guidance" style="margin-top:8px;font-size:10px">Based on validated AQI ${Math.round(S().latest.validated_AQI)} (${h.category}). General environmental guidance — not a medical diagnosis.</p>`;
}

function renderAlerts() {
  $("alerts-block").innerHTML = S().alerts.map(a => `
    <div class="alert-card" style="border-left-color:${a.color}">
      <div class="alert-title" style="color:${a.color}">${a.level}</div>
      <div class="alert-msg">${a.msg}</div>
      <div class="alert-rec">▸ ${a.rec}</div>
    </div>`).join("");
}

function renderWhatIf() {
  const l = S().latest;
  const { aqi, scenPM25 } = scenarioSubs();
  const curAQI = l.validated_AQI;
  const curCat = aqiCategory(curAQI), scenCat = aqiCategory(aqi);
  const delta = curAQI ? ((aqi - curAQI) / curAQI * 100) : 0;

  /* scenario risk score: swap severity factor, keep the rest */
  const r = S().risk;
  const sev = Math.min(aqi / 300 * 100, 100);
  const scenScore = Math.round(Math.min(Math.max(
    sev * r.weights["Pollutant severity"] +
    r.factors["Pollution trend"] * r.weights["Pollution trend"] +
    r.factors["Forecast risk"] * r.weights["Forecast risk"] +
    r.factors["Data quality"] * r.weights["Data quality"] +
    r.factors["Sensor anomaly"] * r.weights["Sensor anomaly"], 0), 100));

  const row = (label, cur, scen, col) => `
    <div class="whatif-metric"><div class="wm-label">${label}</div>
      <div class="whatif-compare">
        <span class="wc-current">${cur}</span><span class="wc-arrow">→</span>
        <span class="wc-scenario" style="color:${col}">${scen}</span>
      </div></div>`;

  $("whatif-block").innerHTML = `
    ${row("PM2.5 (µg/m³)", l["PM2.5"], scenPM25, "#29d8e0")}
    ${row("Validated AQI", Math.round(curAQI), Math.round(aqi), CAT_COLORS[scenCat])}
    ${row("Risk Category", curCat, scenCat, CAT_COLORS[scenCat])}
    ${row("Risk Score", S().risk.score + "/100", scenScore + "/100", "#29d8e0")}
    <div class="whatif-metric"><div class="wm-label">Estimated AQI change</div>
      <div class="whatif-delta" style="margin-top:0"><b style="color:${delta > 0 ? "var(--unhealthy)" : delta < 0 ? "var(--good)" : "var(--text-dim)"}">${delta > 0 ? "+" : ""}${delta.toFixed(1)}%</b></div>
    </div>`;
  renderRisk(state.whatif !== 0 ? scenScore : undefined);
}

function renderRecommendations() {
  $("recommendation-block").innerHTML =
    `<ul>${S().recommendations.map(r => `<li>${r}</li>`).join("")}</ul>`;
}

function renderDataQuality() {
  const q = S().data_quality;
  const v = DATA.validation;
  const flags = Object.entries(v).filter(([, x]) => !x.trusted)
    .map(([p, x]) => `⚠ Source <b>AQI_${p}</b> failed validation (source max ${Math.round(x.source_max)} vs recomputed max ${Math.round(x.recomputed_max)}) — recomputed values used instead.`);
  $("dataquality-block").innerHTML = `
    <div class="dq-stat"><div class="dq-val" style="color:var(--good)">${q.valid_records}</div><div class="dq-label">Valid records</div></div>
    <div class="dq-stat"><div class="dq-val" style="color:var(--amber)">${q.incomplete_records}</div><div class="dq-label">Incomplete records</div></div>
    <div class="dq-stat"><div class="dq-val" style="color:var(--unhealthy)">${q.missing_records}</div><div class="dq-label">Missing records</div></div>
    <div class="dq-stat"><div class="dq-val">${q.reliability_pct}%</div><div class="dq-label">Sensor reliability</div></div>
    <div class="dq-note">Last data timestamp: <b>${q.last_timestamp}</b> · Anomaly-flagged records: <b>${q.anomaly_records}</b><br>
      AQI validation: ${flags.length ? flags.join(" ") : "all source AQI columns agree with recomputation."}
      Invalid records are excluded from KPI, risk and forecast calculations.</div>`;
}
